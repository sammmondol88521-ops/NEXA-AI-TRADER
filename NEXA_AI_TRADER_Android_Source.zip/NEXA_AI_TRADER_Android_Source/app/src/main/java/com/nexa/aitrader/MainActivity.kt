package com.nexa.aitrader

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var apiKeyInput: EditText
    private lateinit var symbolInput: EditText
    private lateinit var marketSpinner: Spinner
    private lateinit var signalText: TextView
    private lateinit var detailText: TextView
    private lateinit var statusText: TextView
    private lateinit var refreshButton: Button
    private lateinit var autoSwitch: Switch
    private var busy = false

    private val markets = arrayOf("Forex", "Gold", "Crypto", "Indices")
    private val presets = mapOf(
        "Forex" to "EUR/USD",
        "Gold" to "XAU/USD",
        "Crypto" to "BTC/USD",
        "Indices" to "SPX"
    )

    private val refreshTask = object : Runnable {
        override fun run() {
            if (autoSwitch.isChecked) analyze()
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handler.postDelayed(refreshTask, 30_000L)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF3F6FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll)

        val title = TextView(this).apply {
            text = "NEXA AI TRADER"
            textSize = 25f
            setTextColor(0xFF10233F.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(title)
        content.addView(label("DEMO MARKET ANALYZER  •  NO AUTO-TRADING"))
        content.addView(space(14))

        content.addView(label("Twelve Data API key"))
        apiKeyInput = EditText(this).apply {
            hint = "Paste your free API key"
            textSize = 14f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
        }
        content.addView(apiKeyInput, matchWrap())

        content.addView(label("Market category"))
        marketSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                markets
            )
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    symbolInput.setText(presets[markets[position]] ?: "EUR/USD")
                }
            }
        }
        content.addView(marketSpinner, matchWrap())

        content.addView(label("Symbol (edit if your data plan supports it)"))
        symbolInput = EditText(this).apply {
            setText("EUR/USD")
            hint = "Example: EUR/USD, BTC/USD, XAU/USD"
            textSize = 14f
            singleLine = true
        }
        content.addView(symbolInput, matchWrap())

        content.addView(space(8))
        autoSwitch = Switch(this).apply {
            text = "Auto-analyze every 30 seconds"
            isChecked = true
            textSize = 15f
            setTextColor(0xFF26364A.toInt())
        }
        content.addView(autoSwitch)

        refreshButton = Button(this).apply {
            text = "ANALYZE NOW"
            setOnClickListener { analyze() }
        }
        content.addView(refreshButton, matchWrap())

        content.addView(space(14))
        val signalCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            setBackgroundColor(0xFF10233F.toInt())
        }
        signalText = TextView(this).apply {
            text = "WAIT"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val demoLabel = TextView(this).apply {
            text = "ILLUSTRATIVE DEMO SIGNAL — NOT A TRADE INSTRUCTION"
            textSize = 10f
            setTextColor(0xFFB9C9DD.toInt())
            gravity = Gravity.CENTER
        }
        signalCard.addView(signalText)
        signalCard.addView(demoLabel)
        content.addView(signalCard, matchWrap())

        statusText = label("Status: Add an API key, then tap Analyze Now.")
        content.addView(statusText)
        detailText = TextView(this).apply {
            text = "Indicators and analysis will appear here."
            textSize = 14f
            setTextColor(0xFF26364A.toInt())
            setPadding(0, dp(12), 0, dp(12))
        }
        content.addView(detailText)

        val warning = TextView(this).apply {
            text = "Risk notice: This app is educational software. BUY/SELL/WAIT is a rule-based technical scenario, not a prediction or financial advice. One-minute price moves are highly unpredictable. Never use this as the sole basis for a trade. No Quotex connection, account login, deposits, or automatic orders."
            textSize = 12f
            setTextColor(0xFF8A3A22.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFFFE9DD.toInt())
        }
        content.addView(warning)
        setContentView(root)
    }

    private fun analyze() {
        if (busy) return
        val key = apiKeyInput.text.toString().trim()
        val symbol = symbolInput.text.toString().trim().uppercase(Locale.US)
        if (key.isBlank()) {
            statusText.text = "Status: Please add a Twelve Data API key."
            return
        }
        if (symbol.isBlank()) {
            statusText.text = "Status: Enter a market symbol."
            return
        }
        busy = true
        refreshButton.isEnabled = false
        statusText.text = "Status: Fetching latest 1-minute candles for $symbol..."
        executor.execute {
            try {
                val urlSymbol = URLEncoder.encode(symbol, "UTF-8")
                val urlKey = URLEncoder.encode(key, "UTF-8")
                val endpoint = "https://api.twelvedata.com/time_series?symbol=$urlSymbol&interval=1min&outputsize=100&apikey=$urlKey"
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12_000
                    readTimeout = 12_000
                }
                val body = try {
                    val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                    stream.bufferedReader().use { it.readText() }
                } finally {
                    connection.disconnect()
                }
                val json = JSONObject(body)
                if (json.has("status") && json.optString("status") == "error") {
                    throw IllegalStateException(json.optString("message", "Market data API error"))
                }
                val values = json.optJSONArray("values") ?: throw IllegalStateException(
                    json.optString("message", "No candle data returned. Check symbol/API access.")
                )
                val closes = ArrayList<Double>()
                for (i in values.length() - 1 downTo 0) {
                    val close = values.getJSONObject(i).optString("close").toDoubleOrNull()
                    if (close != null) closes.add(close)
                }
                if (closes.size < 35) throw IllegalStateException("Not enough candles for indicators.")
                val result = calculate(closes)
                runOnUiThread {
                    signalText.text = result.signal
                    signalText.setTextColor(
                        when (result.signal) {
                            "BUY" -> 0xFF8FE3B0.toInt()
                            "SELL" -> 0xFFFFA6A6.toInt()
                            else -> 0xFFFFFFFF.toInt()
                        }
                    )
                    val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    statusText.text = "Updated $stamp  •  $symbol  •  1-minute candles"
                    detailText.text = result.details
                }
            } catch (e: Exception) {
                runOnUiThread {
                    signalText.text = "WAIT"
                    signalText.setTextColor(0xFFFFFFFF.toInt())
                    statusText.text = "Status: Analysis unavailable"
                    detailText.text = e.message ?: "Unknown error. Check internet, API key, symbol and API limits."
                }
            } finally {
                runOnUiThread {
                    busy = false
                    refreshButton.isEnabled = true
                }
            }
        }
    }

    private data class Analysis(val signal: String, val details: String)

    private fun calculate(c: List<Double>): Analysis {
        val last = c.last()
        val ema9 = ema(c, 9)
        val ema21 = ema(c, 21)
        val rsi = rsi(c, 14)
        val macdLine = ema(c, 12) - ema(c, 26)
        val macdSeries = (26..c.size).map { end ->
            val part = c.take(end)
            ema(part, 12) - ema(part, 26)
        }
        val macdSignal = if (macdSeries.size >= 9) ema(macdSeries, 9) else macdLine
        val bullish = last > ema9 && ema9 > ema21 && rsi in 52.0..70.0 && macdLine > macdSignal
        val bearish = last < ema9 && ema9 < ema21 && rsi in 30.0..48.0 && macdLine < macdSignal
        val signal = when {
            bullish -> "BUY"
            bearish -> "SELL"
            else -> "WAIT"
        }
        val trend = when {
            ema9 > ema21 -> "Bullish EMA trend"
            ema9 < ema21 -> "Bearish EMA trend"
            else -> "Flat EMA trend"
        }
        val momentum = when {
            macdLine > macdSignal -> "MACD momentum positive"
            macdLine < macdSignal -> "MACD momentum negative"
            else -> "MACD momentum neutral"
        }
        val explanation = when (signal) {
            "BUY" -> "Rule check: price above EMA 9, EMA 9 above EMA 21, RSI in bullish zone, and MACD above its signal line. This is only a bullish technical setup."
            "SELL" -> "Rule check: price below EMA 9, EMA 9 below EMA 21, RSI in bearish zone, and MACD below its signal line. This is only a bearish technical setup."
            else -> "The indicators do not align strongly enough. WAIT is the cautious result; no clear setup is present."
        }
        return Analysis(
            signal,
            String.format(
                Locale.US,
                "Latest close: %.5f\nEMA 9: %.5f\nEMA 21: %.5f\nRSI 14: %.1f\nMACD: %.6f\nMACD signal: %.6f\n\n%s\n%s\n\n%s",
                last, ema9, ema21, rsi, macdLine, macdSignal, trend, momentum, explanation
            )
        )
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1.0)
        var current = values.take(period).average()
        for (i in period until values.size) current = values[i] * k + current * (1.0 - k)
        return current
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        var gains = 0.0
        var losses = 0.0
        val start = (values.size - period - 1).coerceAtLeast(0)
        for (i in start + 1 until values.size) {
            val delta = values[i] - values[i - 1]
            if (delta >= 0) gains += delta else losses -= delta
        }
        val count = (values.size - start - 1).coerceAtLeast(1)
        val avgGain = gains / count
        val avgLoss = losses / count
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(0xFF42536A.toInt())
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        executor.shutdownNow()
        super.onDestroy()
    }
}
