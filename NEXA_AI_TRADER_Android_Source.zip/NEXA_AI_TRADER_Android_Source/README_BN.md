# NEXA AI TRADER — Android source project

এটি একটি **ডেমো টেকনিক্যাল অ্যানালাইজার**। এটি কোনো ট্রেড করে না, Quotex-এ লগইন করে না এবং Quotex-এর OTC ডেটা পড়ার দাবি করে না।

## কী আছে
- Forex, Gold, Crypto, Indices ক্যাটাগরি
- Twelve Data-এর 1-minute candle endpoint থেকে ডেটা আনার চেষ্টা
- EMA 9, EMA 21, RSI 14 এবং MACD হিসাব
- BUY / SELL / WAIT নামে rule-based demo scenario
- প্রতি ৩০ সেকেন্ডে auto-refresh (চালু/বন্ধ করা যায়)
- কোনো auto-trading বা broker integration নেই

## প্রয়োজনীয় বিষয়
- ইন্টারনেট সংযোগ
- Twelve Data-এর API key (তাদের ওয়েবসাইটে বিনামূল্যের প্ল্যান/সীমা যাচাই করুন)
- API key অ্যাপের মধ্যে স্থায়ীভাবে সংরক্ষণ করা হয় না; অ্যাপ চালু থাকা অবস্থায় ইনপুটে দিতে হবে।
- API provider-এর ফ্রি প্ল্যানে সব symbol বা সব request পাওয়া নাও যেতে পারে। `SPX`/`XAU/USD`-এর মতো symbol কাজ না করলে provider-এর symbol search-এ সমর্থিত symbol দেখে লিখুন।
- প্রতি ৩০ সেকেন্ডে একটি symbol-এর জন্য request পাঠায়। সব মার্কেট একসঙ্গে স্ক্যান করে না; ক্যাটাগরি ও symbol বদলে আলাদা করে বিশ্লেষণ করতে হবে।

## APK কীভাবে বানাবেন
এই ZIP হলো Android Studio source project, তৈরি করা APK নয়। APK build করতে Android Studio-সহ একটি কম্পিউটার লাগবে:

1. ZIP extract করুন।
2. Android Studio খুলে `NEXA_AI_TRADER_Android_Source` ফোল্ডারটি Open করুন।
3. Gradle sync শেষ হতে দিন।
4. `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)` নির্বাচন করুন।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

শুধু Android ফোন থাকলে এই source project সরাসরি APK-তে compile করা সহজ নয়; Android Studio-সহ PC বা বিশ্বস্ত cloud build পরিবেশ লাগবে।

## সীমাবদ্ধতা ও নিরাপত্তা
- ৩০ সেকেন্ড হলো ডেটা refresh interval; এটি ৩০ সেকেন্ডের মধ্যে লাভজনক entry নিশ্চিত করে না।
- ১ মিনিটের binary/digital option-এর ফল অনুমান করা অত্যন্ত কঠিন।
- BUY/SELL/WAIT হলো সরল indicator alignment-এর শিক্ষামূলক ফল, AI prediction নয়।
- API data এবং Quotex/OTC quote আলাদা হতে পারে।
- API key কাউকে দেবেন না। অচেনা APK, Telegram bot, referral বা Quotex password চাইলে ব্যবহার করবেন না।
- বাস্তব অর্থে ব্যবহার করবেন না; demo/শিক্ষামূলক উদ্দেশ্যেই রাখুন।

## ব্যবহৃত ডেটা API
Twelve Data time series endpoint:
`https://api.twelvedata.com/time_series`
